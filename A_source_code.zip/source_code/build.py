#!/usr/bin/env python3
"""金本位元帅历史策略审计：离线生成纯静态 GitHub Pages 网站。"""
import argparse
import csv
import datetime as dt
import json
import math
import pathlib
import re
import time
import zipfile
import xml.etree.ElementTree as ET
from zoneinfo import ZoneInfo

import requests

ROOT = pathlib.Path(__file__).resolve().parent
TZ = ZoneInfo('Asia/Shanghai')
NS = {'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
WINDOWS = [('15m',15),('1h',60),('4h',240),('12h',720),('24h',1440),('48h',2880),('72h',4320),('168h',10080)]
ALIASES = {'15m':['15分钟后'], '1h':['1小时后'], '4h':['4小时后'], '12h':['12小时后'], '24h':['1天后','24小时后'], '48h':['2天后','48小时后'], '72h':['3天后','72小时后'], '168h':['1周后','一周后','7天后']}

def read_excel(path):
    """直接读取xlsx XML，避免用户必须安装重量级表格依赖。"""
    with zipfile.ZipFile(path) as z:
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            sr=ET.fromstring(z.read('xl/sharedStrings.xml'))
            shared=[''.join(t.text or '' for t in si.findall('.//x:t',NS)) for si in sr.findall('x:si',NS)]
        book=ET.fromstring(z.read('xl/workbook.xml'))
        rel=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        targets={x.attrib['Id']:x.attrib['Target'] for x in rel}
        sheets=[]
        for s in book.findall('.//x:sheet',NS):
            target=targets[s.attrib['{%s}id'%NS['r']]].lstrip('/')
            target=target if target.startswith('xl/') else 'xl/'+target
            if target in z.namelist():sheets.append((s.attrib['name'],target))
        for name,target in sheets:
            rows=[]
            for row in ET.fromstring(z.read(target)).findall('.//x:sheetData/x:row',NS):
                cells={}
                for c in row.findall('x:c',NS):
                    letters=re.match(r'[A-Z]+',c.attrib['r']).group();idx=0
                    for ch in letters:idx=idx*26+ord(ch)-64
                    typ=c.attrib.get('t','');v=c.find('x:v',NS);inline=c.find('x:is',NS)
                    val=v.text if v is not None else ''
                    if typ=='s' and val:val=shared[int(val)]
                    elif typ=='inlineStr' and inline is not None:val=''.join(x.text or '' for x in inline.findall('.//x:t',NS))
                    elif typ not in ('s','str','inlineStr') and val:
                        try:val=float(val)
                        except ValueError:pass
                    cells[idx-1]=val
                if cells:rows.append([cells.get(i,'') for i in range(max(cells)+1)])
            if rows and any('发言时间' in str(x) for x in rows[0]) and any('标的' in str(x) for x in rows[0]):return name,rows
    raise ValueError('未找到包含“发言时间”和“标的”表头的工作表')

def parse_time(v):
    if isinstance(v,(int,float)):
        return dt.datetime(1899,12,30,tzinfo=TZ)+dt.timedelta(days=v)
    s=re.sub(r'\s*\(.*?\)','',str(v).strip().replace('T',' ').replace('Z',''))
    try:return dt.datetime.fromisoformat(s).replace(tzinfo=TZ)
    except ValueError:raise ValueError('无法识别时间: '+s)

def number(v):
    if isinstance(v,bool):return None
    try:
        n=float(str(v).strip().replace(',',''))
        return n if math.isfinite(n) else None
    except (ValueError,TypeError):return None

def symbol_name(v,mapping):
    raw=str(v).strip().upper().replace(' ','')
    if raw in ('','NONE','NAN','-','无'):return ''
    if raw in mapping:return mapping[raw]
    return raw.replace('/USDT','').removesuffix('USDT')+'USDT'

def snapshot(v):
    """支持原回测Excel中“价格 X\\n涨跌 +Y%”及纯数值价格。"""
    if isinstance(v,(int,float)):return number(v)
    text=str(v or '')
    found=re.search(r'价格\s*[:：]?\s*([\d\.eE+-]+)',text)
    return number(found.group(1)) if found else None

def get_klines(session,symbol,start,end,cache,offline=False):
    # 毫秒级边界进入缓存键，防止同日多条策略共用错位的文件。
    key=f'{symbol}_{start}_{end}.json';path=cache/key
    if path.exists():return json.loads(path.read_text(encoding='utf8'))
    if offline:return []
    out=[];cur=start
    while cur<end:
        chunk=None;err=None
        for retry in range(4):
            try:
                resp=session.get('https://fapi.binance.com/fapi/v1/klines',params={
                    'symbol':symbol,'interval':'5m','startTime':cur,'endTime':end-1,'limit':1500},timeout=22)
                if resp.status_code in (418,429):
                    time.sleep(3*(retry+1));continue
                resp.raise_for_status();chunk=resp.json()
                if not isinstance(chunk,list):raise ValueError(str(chunk))
                break
            except Exception as e:
                err=e;time.sleep(1.5*(retry+1))
        if chunk is None:raise RuntimeError(f'{symbol}: {err or "接口限流"}')
        if not chunk:break
        out.extend([[int(k[0]),float(k[1]),float(k[2]),float(k[3]),float(k[4]),float(k[5])] for k in chunk])
        nxt=int(chunk[-1][0])+300000
        if nxt<=cur:break
        cur=nxt
        if len(chunk)<1500:break
        time.sleep(.13)
    path.write_text(json.dumps(out,separators=(',',':')),encoding='utf8')
    return out

def has_coverage(ks,first,last):
    """窗口终点已有行情才进入比例统计，避免未来尚未发生或退市样本误计。"""
    return bool(ks and ks[0][0]<=first+300000 and ks[-1][0]+300000>=last)

def compute(ks,pub,base,points):
    t=int(pub.timestamp()*1000)
    metric={'status':'仅表格快照' if any(p['price'] is not None for p in points.values()) else '未采集行情','base':base,
            'points':points,'pre14_position_pct':None,'mfe_pct':None,'mae_pct':None,
            'target48_hit':None,'target48_valid':False,'complete48':False}
    if not ks:return metric
    ks.sort(key=lambda x:x[0]);ks=[k for i,k in enumerate(ks) if i==0 or k[0]!=ks[i-1][0]]
    past=[k for k in ks if k[0]+300000<=t]
    if base is None:
        base=past[-1][4] if past else next((k[1] for k in ks if k[0]<=t<k[0]+300000),None)
    metric['base']=base
    if not base or base<=0:
        metric['status']='缺少有效基准价';return metric
    metric['status']='K线已采集'
    pre=[k for k in ks if t-14*86400000<=k[0] and k[0]+300000<=t]
    after=[k for k in ks if t<=k[0]<t+14*86400000]
    if pre:
        lo=min(k[3] for k in pre);hi=max(k[2] for k in pre)
        metric['pre14_position_pct']=(base-lo)/(hi-lo)*100 if hi>lo else None
    if after:
        metric['mfe_pct']=(max(k[2] for k in after)/base-1)*100
        metric['mae_pct']=(min(k[3] for k in after)/base-1)*100
    for key,minutes in WINDOWS:
        target=t+minutes*60000
        # 优先使用原Excel分钟级快照；如果没有，从包含目标时刻的5m K线取开盘价（近似）。
        if points[key]['price'] is None:
            candle=next((k for k in ks if k[0]<=target<k[0]+300000),None)
            if candle:points[key]={'price':candle[1],'pct':(candle[1]/base-1)*100,'source':'5分钟K线近似'}
        elif points[key]['pct'] is None:
            points[key]['pct']=(points[key]['price']/base-1)*100
    metric['complete48']=has_coverage(ks,t,t+48*3600000)
    return metric

def main():
    ap=argparse.ArgumentParser(description='离线构建金本位元帅历史策略审计网页')
    ap.add_argument('xlsx',help='原始含序号、发言时间、内容、标的的Excel')
    ap.add_argument('--out',default='site');ap.add_argument('--offline',action='store_true')
    ap.add_argument('--mapping',default='mapping.json');ap.add_argument('--meta',default='strategy_metadata.csv')
    args=ap.parse_args()
    out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=True)
    cache=ROOT/'cache';cache.mkdir(exist_ok=True)
    mapping=json.loads((ROOT/args.mapping).read_text(encoding='utf8')) if (ROOT/args.mapping).exists() else {}
    meta={}
    metapath=ROOT/args.meta
    if metapath.exists():
        with metapath.open(encoding='utf-8-sig',newline='') as f:
            for r in csv.DictReader(f):meta[str(r['id'])]=r
    name,rows=read_excel(args.xlsx);header=[str(h).strip() for h in rows[0]]
    def find(*terms):
        for term in terms:
            for i,h in enumerate(header):
                if term in h:return i
        return None
    ti=find('发言时间');ci=find('发言内容','原始发言');si=find('标的');ni=find('序号')
    bi=find('发布价');code_idx=find('币安合约')
    if any(i is None for i in (ti,ci,si,ni)):raise ValueError('Excel必须包含序号、发言时间、发言内容、标的列')
    indices={key:find(*ALIASES[key]) for key,_ in WINDOWS}
    sess=requests.Session();sess.headers.update({'User-Agent':'StrategyAudit-Offline/4.0'})
    now=int(dt.datetime.now(dt.timezone.utc).timestamp()*1000)
    items=[]
    for count,row in enumerate(rows[1:],1):
        value=lambda i:row[i] if i is not None and i<len(row) else ''
        if not str(value(ti)).strip():continue
        try:pub=parse_time(value(ti))
        except ValueError as e:print('跳过错误时间',count,e);continue
        rid=str(value(ni)).strip().removesuffix('.0') or str(count)
        meta_row=meta.get(rid,{})
        sym=symbol_name(value(si),mapping)
        if code_idx is not None:
            supplied=str(value(code_idx)).strip().upper()
            if supplied.endswith('USDT'):sym=supplied
        base=number(value(bi))
        points={key:{'price':snapshot(value(indices[key])),'pct':None,'source':'Excel分钟级快照'} for key,_ in WINDOWS}
        for p in points.values():
            if base and p['price'] is not None:p['pct']=(p['price']/base-1)*100
        entry={'id':rid,'row':count+1,'published':pub.isoformat(),'label':str(value(si)).strip(),
               'symbol':sym,'content':str(value(ci)),'kind':meta_row.get('kind','未分类'),
               'target':number(meta_row.get('target')),'kline':None}
        ks=[];message=''
        if sym:
            start=(int((pub-dt.timedelta(days=14)).timestamp()*1000)//300000)*300000
            end=(int((pub+dt.timedelta(days=14)).timestamp()*1000)//300000)*300000
            end=min(end,(now//300000)*300000)
            if end>start:
                try:
                    ks=get_klines(sess,sym,start,end,cache,args.offline)
                    if ks:
                        fname=f'k_{count:03d}.json';(out/fname).write_text(json.dumps(ks,separators=(',',':')),encoding='utf8')
                        entry['kline']=fname
                except Exception as e:message=str(e)
        m=compute(ks,pub,base,points)
        if not sym:m['status']='未标注标的'
        if message:m['warning']='行情接口失败：'+message[:180]
        target=entry['target']
        # 统计48小时目标命中率：仅明确/建议参与、有效向上目标、完整48h K线，高价触及即视为触及（不是成交）。
        long_entry=entry['kind'] in ('明确买入/已买','建议参与/偏多')
        if long_entry and target is not None and m['base'] and target>m['base'] and m['complete48']:
            t=int(pub.timestamp()*1000)
            window=[k for k in ks if t<=k[0]<t+48*3600000]
            if window:
                m['target48_valid']=True
                m['target48_hit']=any(k[2]>=target for k in window)
        entry['metrics']=m
        items.append(entry)
        print(f'{count}/{len(rows)-1} {rid} {sym or "无标的"}: {m["status"]}',flush=True)
    (out/'data.json').write_text(json.dumps(items,ensure_ascii=False,separators=(',',':')),encoding='utf8')
    (out/'index.html').write_text((ROOT/'index.html').read_text(encoding='utf8'),encoding='utf8')
    (out/'comments.html').write_text((ROOT/'comments.html').read_text(encoding='utf8'),encoding='utf8')
    # Copy the owner-provided public Giscus configuration to the generated Pages site.
    (out/'comments-config.json').write_text((ROOT/'comments-config.json').read_text(encoding='utf8'),encoding='utf8')
    (out/'.nojekyll').write_text('',encoding='utf8')
    with (out/'audit.csv').open('w',encoding='utf-8-sig',newline='') as f:
        fields=['id','published','label','symbol','kind','content','status','base','target','target48_hit','pre14_position_pct','mfe_pct','mae_pct']
        fields += [f'price_{key}' for key,_ in WINDOWS]+[f'pct_{key}' for key,_ in WINDOWS]
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for item in items:
            m=item['metrics'];row={key:item.get(key,m.get(key)) for key in fields}
            row['status']=m['status'];row['base']=m['base'];row['target48_hit']=m['target48_hit']
            for key,_ in WINDOWS:
                row['price_'+key]=m['points'][key]['price'];row['pct_'+key]=m['points'][key]['pct']
            writer.writerow(row)
    print('完成',out.resolve(),'策略数',len(items),'K线有效',sum(bool(i['kline']) for i in items))

if __name__=='__main__':main()
